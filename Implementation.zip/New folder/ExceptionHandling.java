package Package1;

public class ExceptionHandling {

	public static void main(String[] args) {
		try{  
		       
		      int data=22/0;  
		   }
		catch(ArithmeticException e)
		{
			System.out.println(e+" not possible");
		}  

 
	}

}
