package Package1;

public class For_loop {

	public static void main(String[] args) {
		for(int a=5;a<=20;a++) {
			System.out.println(a);
		}
	}

}
