package Package1;
import java.util.*;  
public class HashMap{  
 public static void main(String args[]){  
   HashMap<Integer,String> map=new HashMap<Integer,String>();    
   map.put(1,"Oneplus");    
   map.put(2,"Apple");    
   map.put(3,"Samsung");   
   map.put(4,"Xiaomi");   
       
   
  
   for(Map.Entry m : map.entrySet())
   {    
    System.out.println(m.getKey()+" "+m.getValue());    
   }  
}  
}  